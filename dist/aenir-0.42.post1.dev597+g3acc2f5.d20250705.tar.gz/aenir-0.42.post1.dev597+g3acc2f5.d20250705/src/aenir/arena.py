"""
"""

# TODO: For holy-water and mounting bonuses, need a temporary array of stats to toggle to easily.
# *

# save these for the arena, eh?
def use_holy_water(self):
    """
    """
    raise NotImplementedError

def degrade_holy_water(self):
    """
    """
    raise NotImplementedError

# 4
# TODO: What about rings?
def use_stat_booster(self, item_name: str):
    """
    """
    raise NotImplementedError("Not implemented by design; FE4 has no permanent stat booster items.")

# 5
def use_holy_water(self):
    """
    """
    raise NotImplementedError

def degrade_holy_water(self):
    """
    """
    raise NotImplementedError

self.is_mounted = None
def mount(self):
    """
    """
    raise NotImplementedError("Implementing this will result in more convolution than I can be arsed to deal with.")

def unmount(self):
    """
    """
    raise NotImplementedError("Implementing this will result in more convolution than I can be arsed to deal with.")

# 6
def use_holy_water(self):
    """
    """
    raise NotImplementedError

def degrade_holy_water(self):
    """
    """
    raise NotImplementedError

# 7
def use_holy_water(self):
    """
    """
    raise NotImplementedError

def degrade_holy_water(self):
    """
    """
    raise NotImplementedError

# 8
def use_holy_water(self):
    """
    """
    raise NotImplementedError

def degrade_holy_water(self):
    """
    """
    raise NotImplementedError

# 9
def use_holy_water(self):
    """
    """
    raise NotImplementedError

def degrade_holy_water(self):
    """
    """
    raise NotImplementedError

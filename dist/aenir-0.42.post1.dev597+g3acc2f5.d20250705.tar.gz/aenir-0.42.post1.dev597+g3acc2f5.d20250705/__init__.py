#!/usr/bin/python3
"""
Package for comparing the stats of FE[4-9] units.

Simulates level-ups, promotions, among other things.
"""

if __name__ == '__main__':
    # https://github.com/gchang12/aenir
    pass
